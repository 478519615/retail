import pandas as pd
import matplotlib.pyplot as plt

detail = pd.read_csv("meal_order_detail.csv")
info = pd.read_csv("meal_order_info.csv")

#描述性统计分析(结果输出到文件'detail_describe.csv'和'info_describe.csv')
detail_describe = pd.DataFrame(detail.describe())
info_describe = pd.DataFrame(info.describe())
detail_describe.to_csv('detail_describe.csv')
info_describe.to_csv('info_describe.csv')

#去除dishes_name中的\r\n
for i in range(10037) :
    detail.iloc[i, 3] = detail.iloc[i, 3].strip()

#菜品热销度评分计算(结果输出到csv文件'dishes_score.csv')
dishes_counts = detail.groupby(by='dishes_name').agg({'counts':'count'})
dishes_counts = dishes_counts.sort_index(ascending=True,by='counts')
dishes_score = dishes_counts
for i in range(145):
    dishes_score.iloc[i,0]=(dishes_counts.iloc[i,0]-3)/(269-3)
dishes_score.to_csv('dishes_score.csv')

#绘制条形图展示热销Top10
#中文乱码处理
plt.rcParams['font.sans-serif'] = [u'SimHei']
plt.rcParams['axes.unicode_minus'] = False
dishes_score = pd.read_csv("dishes_score.csv")
Name = dishes_score.iloc[134:143,0]
Count = dishes_score.iloc[134:143,1]
b=plt.barh(Name,Count)
plt.title('菜品热销Top10')
#添加数据标签
for rect in b:
    w = rect.get_width()
    plt.text(w, rect.get_y()+rect.get_height()/2, '%.3f' % w, ha='left', va='center')
#设置横坐标取值范围
axes = plt.gca()
axes.set_xlim([0,1.08])
plt.show()

#绘制p（平均值）关于n的折线图
x_data = ['5', '6', '7', '8', '9', '10']
y_data = [0.19007, 0.19031, 0.20314, 0.21941, 0.20134, 0.19609]
plt.plot(x_data, y_data)
plt.title('p关于n的变化')
plt.show()