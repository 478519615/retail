import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from collections import defaultdict

detail = pd.read_csv("meal_order_detail.csv")
info = pd.read_csv("meal_order_info.csv")

#去除dishes_name中的\r\n
for i in range(9528) :
    detail.iloc[i, 3] = detail.iloc[i, 3].strip()

#去除detail中info里没有的订单
detail = detail[detail['order_id'].isin(info['info_id'])]

#划分meal_order_info表中的emp_id（372:94）
train_target,test_target = train_test_split(info['emp_id'].drop_duplicates().as_matrix(),test_size=0.2)

#基于meal_order_detail表中的dishes_name和emp_id生成二元矩阵
#剔除米饭后，菜品种类为143
dishes_counts = detail.groupby(by='dishes_name').agg({'counts':'count'})
train = pd.DataFrame(data=0,index=train_target,columns=dishes_counts.index)
test = pd.DataFrame(data=0,index=test_target,columns=dishes_counts.index)

for i in train.index:
    for ii in detail[['dishes_name','emp_id']].loc[(detail['emp_id'] == i)].iloc[:,0]:
        train.loc[i,ii]=1

for i in test.index:
    for ii in detail[['dishes_name','emp_id']].loc[(detail['emp_id'] == i)].iloc[:,0]:
        test.loc[i,ii]=1

#计算相似度矩阵
jaccard = np.ones((143,143))*0
for i in range(142):
    a = i+1
    while a<143:
        b = 0
        c = 0
        for ii in range(372):
            b = b + train.iloc[ii, i] * train.iloc[ii, a]
        for ii in range(372):
            c = c + train.iloc[ii, i] + train.iloc[ii, a]
        jaccard[i,a] = b/(c-b)
        a = a+1

jaccard = jaccard + jaccard.T
test_a = test.values
p_dishes = np.dot(test_a,jaccard) #矩阵94*143

#菜品推荐列表的生成原则
n = 8

#创建菜品推荐名单
#结果输出到文件"p_dishes_name.csv"
p_dishes_name = defaultdict(list) #为字典提供默认值
p_dishes_code = np.ones((94,143))*0
for i in range(94):
    a = p_dishes[i,:]
    for ii in range(n):
        b = a.argmax()
        p_dishes_name[test_target[i]].append(dishes_counts.index[b])
        p_dishes_code[i,b] = 1
        a[b] = -1

pd.DataFrame(p_dishes_name).to_csv("p_dishes_name.csv")

#计算正确率
p_dishes_matrix = np.multiply(p_dishes_code,test)
p_dishes_count = 0
for i in range(94):
    for j in range(143):
        p_dishes_count = p_dishes_count + p_dishes_matrix.iloc[i,j]
p_dishes_accuracy = p_dishes_count/(n*94)

print(p_dishes_accuracy)





